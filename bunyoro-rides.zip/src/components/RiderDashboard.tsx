import React, { useState, useEffect } from 'react';
import { Bike, MapPin, Navigation, User as UserIcon, CheckCircle, Clock } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, query, where, onSnapshot, doc, updateDoc, serverTimestamp, getDoc } from 'firebase/firestore';
import { Ride, UserProfile, Location } from '../types';

interface RiderDashboardProps {
  userId: string;
}

export const RiderDashboard: React.FC<RiderDashboardProps> = ({ userId }) => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [availableRides, setAvailableRides] = useState<Ride[]>([]);
  const [activeRide, setActiveRide] = useState<Ride | null>(null);
  const [isOnline, setIsOnline] = useState(false);

  useEffect(() => {
    // Real-time location for rider
    let watchId: number;
    if (navigator.geolocation) {
       watchId = navigator.geolocation.watchPosition((pos) => {
          updateDoc(doc(db, 'users', userId), {
            location: {
              lat: pos.coords.latitude,
              lng: pos.coords.longitude,
              timestamp: Date.now() // Use client timestamp to avoid serverTimestamp strict errors in mock
            },
            updatedAt: serverTimestamp()
          }).catch(e => console.error("Location update failed", e));
       }, undefined, { enableHighAccuracy: true });
    }

    const unsubProfile = onSnapshot(doc(db, 'users', userId), (doc) => {
      if (doc.exists()) {
        const data = doc.data() as UserProfile;
        setProfile(data);
        setIsOnline(data.isOnline || false);
      }
    }, (error) => {
      console.warn("Profile snapshot failed:", error);
      // We don't throw handleFirestoreError here to avoid crashing the dashboard entirely
    });

    // Listen for ride requests
    const qRequests = query(
      collection(db, 'rides'),
      where('status', '==', 'requested')
    );

    const unsubRequests = onSnapshot(qRequests, (snapshot) => {
      const rides = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Ride));
      setAvailableRides(rides);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'rides'));

    // Listen for my accepted rides
    const qMyRides = query(
      collection(db, 'rides'),
      where('riderId', '==', userId),
      where('status', 'in', ['accepted', 'picked_up'])
    );

    const unsubMyRides = onSnapshot(qMyRides, (snapshot) => {
      const rides = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Ride));
      setActiveRide(rides[0] || null);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'rides'));

    return () => {
      if (watchId !== undefined && navigator.geolocation) {
         navigator.geolocation.clearWatch(watchId);
      }
      unsubProfile();
      unsubRequests();
      unsubMyRides();
    };
  }, [userId]);

  const toggleOnline = async () => {
    const nextState = !isOnline;
    try {
      await updateDoc(doc(db, 'users', userId), {
        isOnline: nextState,
        updatedAt: serverTimestamp()
      });
      setIsOnline(nextState);
    } catch (err) {
      console.error(err);
    }
  };

  const acceptRide = async (rideId: string) => {
    try {
      await updateDoc(doc(db, 'rides', rideId), {
        riderId: userId,
        status: 'accepted',
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      console.error(err);
    }
  };

  const updateRideStatus = async (status: 'picked_up' | 'completed') => {
    if (!activeRide) return;
    try {
      await updateDoc(doc(db, 'rides', activeRide.id), {
        status,
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="p-4 space-y-6 max-w-md mx-auto h-[calc(100vh-140px)] overflow-y-auto">
      <header className="bg-white/5 border border-white/10 p-6 rounded-[32px] flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-4">
           <div className={`w-3 h-3 rounded-full ${isOnline ? 'bg-green-500 shadow-lg shadow-green-500/50' : 'bg-red-500 shadow-lg shadow-red-500/50'} animate-pulse`} />
           <div>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">System Status</p>
              <p className="text-sm font-bold text-white">{isOnline ? 'Online & Active' : 'Offline'}</p>
           </div>
        </div>
        <button
          onClick={toggleOnline}
          className={`px-6 py-3 rounded-2xl font-bold text-xs tracking-widest transition-all ${isOnline ? 'bg-red-500/10 text-red-500 border border-red-500/20' : 'bg-brand text-black'}`}
        >
          {isOnline ? 'GO OFFLINE' : 'GO ONLINE'}
        </button>
      </header>

      {activeRide ? (
        <div className="bg-brand text-black p-8 rounded-[40px] shadow-2xl space-y-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-10">
             <Bike className="w-24 h-24" />
          </div>
          <div className="relative z-10">
            <h3 className="text-[10px] font-bold uppercase tracking-widest opacity-60">Active Ride</h3>
            <div className="mt-2 flex items-center justify-between">
              <span className="text-3xl font-extrabold">{activeRide.price.toLocaleString()} UGX</span>
              <span className="px-3 py-1 bg-black/10 rounded-full text-[10px] font-bold uppercase">{activeRide.type}</span>
            </div>
          </div>

          <div className="flex gap-4 p-4 bg-black/5 rounded-2xl">
             <div className="flex flex-col items-center gap-1 mt-1">
                <div className="w-2 h-2 rounded-full bg-black" />
                <div className="w-px h-6 bg-black/20 border-l border-dashed" />
                <div className="w-2 h-2 rounded-full bg-black/40" />
             </div>
             <div className="flex-1 space-y-3">
                <div className="overflow-hidden">
                   <p className="text-[8px] font-bold uppercase opacity-60">Pickup</p>
                   <p className="text-xs font-bold truncate">{activeRide.pickup.address}</p>
                </div>
                <div className="overflow-hidden">
                   <p className="text-[8px] font-bold uppercase opacity-60">Destination</p>
                   <p className="text-xs font-bold truncate">{activeRide.destination.address}</p>
                </div>
             </div>
          </div>

          {/* Ride Status Progress Indicator */}
          <div className="w-full flex items-center justify-between relative px-2 py-2">
             <div className="absolute left-6 right-6 top-5 h-1 bg-black/10 -z-10 rounded-full" />
             <div className="absolute left-6 top-5 h-1 bg-black -z-10 rounded-full transition-all duration-500" style={{ width: activeRide.status === 'accepted' ? '0%' : activeRide.status === 'picked_up' ? '50%' : '100%' }} />
             
             <div className="flex flex-col items-center gap-1.5 z-10 bg-brand">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ring-4 ring-brand ${['accepted', 'picked_up', 'completed'].includes(activeRide.status) ? 'bg-black text-white shadow-sm' : 'bg-black/10 text-black/40'}`}>1</div>
                <span className={`text-[10px] uppercase tracking-widest font-bold ${['accepted', 'picked_up', 'completed'].includes(activeRide.status) ? 'text-black' : 'text-black/50'}`}>En Route</span>
             </div>

             <div className="flex flex-col items-center gap-1.5 z-10 bg-brand px-2">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ring-4 ring-brand ${['picked_up', 'completed'].includes(activeRide.status) ? 'bg-black text-white shadow-sm' : 'bg-black/10 text-black/40'}`}>2</div>
                <span className={`text-[10px] uppercase tracking-widest font-bold ${['picked_up', 'completed'].includes(activeRide.status) ? 'text-black' : 'text-black/50'}`}>Picked Up</span>
             </div>

             <div className="flex flex-col items-center gap-1.5 z-10 bg-brand">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ring-4 ring-brand ${['completed'].includes(activeRide.status) ? 'bg-black text-white shadow-sm' : 'bg-black/10 text-black/40'}`}>3</div>
                <span className={`text-[10px] uppercase tracking-widest font-bold ${['completed'].includes(activeRide.status) ? 'text-black' : 'text-black/50'}`}>Completed</span>
             </div>
          </div>

          <button
            onClick={() => updateRideStatus(activeRide.status === 'accepted' ? 'picked_up' : 'completed')}
            className={`w-full py-5 rounded-3xl font-extrabold text-lg flex items-center justify-center gap-3 active:scale-95 transition-all shadow-xl ${activeRide.status === 'accepted' ? 'bg-black text-white' : 'bg-white text-black'}`}
          >
            {activeRide.status === 'accepted' ? <Bike className="w-6 h-6" /> : <CheckCircle className="w-6 h-6" />}
            {activeRide.status === 'accepted' ? 'Picked Up' : 'Complete Ride'}
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-2">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Nearby Requests</h3>
            <span className="text-[10px] font-bold text-brand bg-brand/5 px-2 py-1 rounded">LIVE</span>
          </div>

          {availableRides.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-24 text-center space-y-6">
              <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center">
                <Clock className="w-10 h-10 text-slate-800" />
              </div>
              <div className="space-y-1">
                <p className="text-white font-bold">No requests nearby</p>
                <p className="text-slate-500 text-xs px-12">Move towards Hoima Central Market for better visibility.</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
               {availableRides.map(ride => (
                 <div key={ride.id} className="bg-white/5 border border-white/5 p-6 rounded-[32px] space-y-4 hover:border-brand/30 transition-all">
                    <div className="flex justify-between items-start">
                       <div>
                          <p className="text-[10px] font-bold text-brand uppercase tracking-widest">New Order</p>
                          <h4 className="text-xl font-extrabold text-white">{ride.price.toLocaleString()} UGX</h4>
                       </div>
                       <span className="px-3 py-1 bg-white/10 rounded-lg text-[8px] font-bold text-slate-400 uppercase tracking-widest">{ride.type}</span>
                    </div>
                    
                    <div className="flex gap-4">
                       <div className="flex flex-col items-center gap-1 mt-1 shrink-0">
                         <div className="w-2 h-2 rounded-full bg-brand" />
                         <div className="w-px h-6 bg-white/10 border-l border-dashed" />
                         <div className="w-2 h-2 rounded-full bg-red-500" />
                       </div>
                       <div className="flex-1 space-y-3">
                          <p className="text-xs font-bold text-slate-300 leading-none truncate">{ride.pickup.address}</p>
                          <p className="text-xs font-bold text-slate-500 leading-none truncate">{ride.destination.address}</p>
                       </div>
                    </div>

                    <button
                      onClick={() => acceptRide(ride.id)}
                      disabled={!isOnline}
                      className="w-full py-4 bg-brand text-black rounded-2xl font-extrabold text-sm hover:bg-brand-dark transition-all disabled:opacity-30 active:scale-95 shadow-lg shadow-brand/10"
                    >
                      ACCEPT RIDE
                    </button>
                 </div>
               ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
