
import React, { useId } from 'react';

export const Logo: React.FC<{ className?: string, color?: string }> = ({ className = "w-20 h-20", color = "currentColor" }) => {
  const maskId = useId();
  const safeMaskId = maskId.replace(/:/g, ""); // Ensure valid id for SVG
  
  return (
    <svg 
      viewBox="0 0 240 240" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg" 
      className={className}
    >
      <defs>
        <mask id={`mask-${safeMaskId}`}>
          {/* Default everything to visible (white) */}
          <rect x="0" y="0" width="240" height="240" fill="white" />
          
          {/* Transparent ring to form the wheel gap */}
          <circle cx="125" cy="155" r="45" fill="none" stroke="black" strokeWidth="18" />
          
          {/* Center dot/axel cut-out */}
          <circle cx="125" cy="155" r="14" fill="black" />
          
          {/* Handlebar fork line */}
          <path d="M 85 45 L 125 155" stroke="black" strokeWidth="13" strokeLinecap="round" />
          
          {/* Handlebar top cross */}
          <path d="M 70 55 L 105 35" stroke="black" strokeWidth="14" strokeLinecap="round" />
          <path d="M 65 65 L 75 48" stroke="black" strokeWidth="14" strokeLinecap="round" />
        </mask>
      </defs>

      {/* The main 'B' shape masked to create true negative space */}
      <path 
        mask={`url(#mask-${safeMaskId})`}
        fillRule="evenodd" 
        clipRule="evenodd" 
        d="M85 40 
           H 145 
           C 185 40 200 60 190 95 
           C 185 110 160 120 160 120 
           C 160 120 205 120 210 165 
           C 215 210 170 230 115 230 
           H 45 
           L 60 150 
           C 65 130 65 140 70 120
           L 85 40 Z" 
        fill={color} 
      />
    </svg>
  );
};
