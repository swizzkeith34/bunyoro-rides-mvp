import React, { useState, useEffect } from 'react';
import { MapPin, Navigation, Bike, Zap, Search, Loader2, Info, Menu, Bell, Star, User as UserIcon, ShieldCheck, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, query, where, onSnapshot, addDoc, serverTimestamp, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { Ride, RideType, Location, RideStatus } from '../types';

interface ClientDashboardProps {
  userId: string;
}

export const ClientDashboard: React.FC<ClientDashboardProps> = ({ userId }) => {
  const [location, setLocation] = useState<Location | null>(null);
  const [destination, setDestination] = useState<string>('');
  const [rideType, setRideType] = useState<RideType>('usual');
  const [activeRide, setActiveRide] = useState<Ride | null>(null);
  const [riderLocation, setRiderLocation] = useState<Location | null>(null);
  const [loading, setLoading] = useState(false);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    // Get geolocation
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLocation({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            address: 'Finding address...'
          });
          // In a real app, we would reverse geocode here
          setTimeout(() => {
            setLocation(prev => prev ? { ...prev, address: `Hoima Center (Simulated)` } : null);
          }, 1000);
        },
        (err) => console.error(err),
        { enableHighAccuracy: true }
      );
    }

    // Listen for active rides
    const q = query(
      collection(db, 'rides'),
      where('clientId', '==', userId),
      where('status', 'in', ['requested', 'accepted', 'picked_up'])
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const rides = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Ride));
      setActiveRide(rides[0] || null);
      if (rides[0] && rides[0].status === 'requested') {
        setSearching(true);
      } else {
        setSearching(false);
      }
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'rides'));

    return () => unsubscribe();
  }, [userId]);

  useEffect(() => {
    if (!activeRide?.riderId) {
      setRiderLocation(null);
      return;
    }

    const unsubRider = onSnapshot(doc(db, 'users', activeRide.riderId), (docSnap) => {
      if (docSnap.exists() && docSnap.data().location) {
        setRiderLocation(docSnap.data().location as Location);
      }
    }, (error) => handleFirestoreError(error, OperationType.GET, `users/${activeRide.riderId}`));

    return () => unsubRider();
  }, [activeRide?.riderId]);

  const placeOrder = async () => {
    if (!location || !destination) return;
    setLoading(true);
    try {
      await addDoc(collection(db, 'rides'), {
        clientId: userId,
        pickup: location,
        destination: { lat: 1.4333, lng: 31.3522, address: destination }, // Simulating destination coords
        type: rideType,
        status: 'requested',
        price: rideType === 'electric' ? 5000 : 3000, // Simulated price in UGX
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const cancelRide = async () => {
    if (!activeRide) return;
    try {
      if (activeRide.status === 'requested') {
        await updateDoc(doc(db, 'rides', activeRide.id), {
          status: 'cancelled',
          updatedAt: serverTimestamp()
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="relative h-[calc(100vh-80px)] bg-[#f8f9fa] overflow-hidden select-none">
      {/* Map Backdrop (Simulation) */}
      <div className="absolute inset-0 bg-[#e9ecef] overflow-hidden">
        {/* Mock Map Texture */}
        <div className="absolute inset-0 opacity-40 bg-[url('https://api.mapbox.com/styles/v1/mapbox/light-v11/static/31.3522,1.4333,14,0/800x800?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4M29iazA2Z2gycXA4N2pmbDZmangifQ.-g_vE53SD2WrJ6tFX7QHmA')] bg-cover bg-center" />
        
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
           <div className="relative">
              <motion.div 
                animate={{ scale: [1, 1.8, 1], opacity: [0.1, 0.2, 0.1] }}
                transition={{ repeat: Infinity, duration: 4 }}
                className="absolute inset-0 bg-brand rounded-full -m-20"
              />
              <div className="relative z-10 w-5 h-5 bg-black rounded-full ring-4 ring-black/10 flex items-center justify-center">
                 <div className="w-2 h-2 bg-brand rounded-full" />
              </div>
              <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 bg-black text-white text-[10px] font-bold px-3 py-1.5 rounded-full whitespace-nowrap shadow-xl">
                 Your Location
              </div>
           </div>
        </div>
      </div>

      {/* Top Header Controls */}
      <div className="absolute top-6 left-6 right-6 flex justify-between items-center z-20">
         <button className="w-12 h-12 bg-white/90 backdrop-blur-md rounded-full flex items-center justify-center text-slate-800 shadow-[0_8px_30px_rgb(0,0,0,0.08)] hover:bg-white transition-colors">
            <Menu className="w-5 h-5" />
         </button>
         <button className="w-12 h-12 bg-white/90 backdrop-blur-md rounded-full flex items-center justify-center text-slate-800 shadow-[0_8px_30px_rgb(0,0,0,0.08)] hover:bg-white transition-colors relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-3 right-3 w-2 h-2 bg-red-500 rounded-full border-2 border-white" />
         </button>
      </div>

      {/* Main UI Bottom Sheet */}
      <div className="absolute bottom-0 left-0 right-0 z-30 flex flex-col items-center">
         {/* Trust Signal Float */}
         {!activeRide && (
           <motion.div 
             initial={{ y: 20, opacity: 0 }}
             animate={{ y: 0, opacity: 1 }}
             transition={{ delay: 0.5 }}
             className="mb-4 bg-white px-4 py-2 rounded-full shadow-[0_8px_30px_rgb(0,0,0,0.12)] flex items-center gap-2"
           >
              <ShieldCheck className="w-4 h-4 text-green-600" />
              <span className="text-xs font-bold text-slate-700 tracking-tight">100% Verified Local Riders</span>
           </motion.div>
         )}

        <AnimatePresence mode="wait">
          {!activeRide ? (
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="w-full max-w-lg bg-white rounded-t-[32px] shadow-[0_-20px_60px_rgba(0,0,0,0.1)] p-6 pt-3 space-y-6"
            >
              <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto mb-4" />

              <div className="space-y-3 relative">
                {/* Connecting Line */}
                <div className="absolute left-7 top-10 bottom-10 w-0.5 bg-slate-100" />

                <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  <div className="w-6 h-6 bg-slate-200 rounded-full flex items-center justify-center shrink-0 z-10 ring-4 ring-slate-50">
                    <div className="w-2 h-2 bg-slate-500 rounded-full" />
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Current Location</p>
                    <p className="text-slate-800 font-bold truncate text-sm mt-0.5">{location?.address || 'Locating...'}</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 bg-white p-4 rounded-2xl border-2 border-brand/20 shadow-[0_8px_30px_rgb(236,132,8,0.08)] group focus-within:border-brand focus-within:ring-4 focus-within:ring-brand/10 transition-all">
                  <div className="w-6 h-6 bg-brand/20 rounded-full flex items-center justify-center shrink-0 z-10 ring-4 ring-white">
                    <div className="w-2 h-2 bg-brand rounded-full" />
                  </div>
                  <div className="flex-1">
                    <p className="text-[10px] font-bold text-brand uppercase tracking-widest">Where to?</p>
                    <input 
                      type="text"
                      placeholder="Search destination in Hoima"
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      className="w-full bg-transparent border-none p-0 focus:ring-0 text-slate-900 font-bold placeholder:text-slate-300 text-base mt-0.5"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <button 
                  onClick={() => setRideType('usual')}
                  className={`w-full relative p-4 rounded-2xl border-2 transition-all flex items-center gap-4 ${rideType === 'usual' ? 'border-brand bg-brand/5 shadow-[0_4px_20px_rgb(218,165,32,0.15)]' : 'border-slate-100 bg-white hover:border-slate-200'}`}
                >
                   <div className={`w-12 h-12 rounded-full flex flex-col items-center justify-center shrink-0 ${rideType === 'usual' ? 'bg-brand text-white' : 'bg-slate-100 text-slate-500'}`}>
                      <Bike className="w-6 h-6" />
                   </div>
                   <div className="text-left flex-1">
                     <span className={`block font-extrabold text-base ${rideType === 'usual' ? 'text-slate-900' : 'text-slate-700'}`}>Standard Boda</span>
                     <span className="block text-sm font-medium text-slate-500 mt-0.5">3 min away</span>
                   </div>
                   <div className="text-right">
                     <span className={`block font-black text-lg ${rideType === 'usual' ? 'text-slate-900' : 'text-slate-700'}`}>UGX 3,000</span>
                   </div>
                   {rideType === 'usual' && (
                     <div className="absolute -top-3 right-4 bg-brand text-white text-[10px] font-bold px-2 py-1 rounded-md tracking-wider shadow-sm uppercase">Fastest</div>
                   )}
                </button>
                <button 
                  onClick={() => setRideType('electric')}
                  className={`w-full relative p-4 rounded-2xl border-2 transition-all flex items-center gap-4 ${rideType === 'electric' ? 'border-brand bg-brand/5 shadow-[0_4px_20px_rgb(218,165,32,0.15)]' : 'border-slate-100 bg-white hover:border-slate-200'}`}
                >
                   <div className={`w-12 h-12 rounded-full flex flex-col items-center justify-center shrink-0 ${rideType === 'electric' ? 'bg-brand text-white' : 'bg-slate-100 text-slate-500'}`}>
                      <Zap className="w-6 h-6" />
                   </div>
                   <div className="text-left flex-1">
                     <span className={`block font-extrabold text-base ${rideType === 'electric' ? 'text-slate-900' : 'text-slate-700'}`}>Electric Boda</span>
                     <span className="block text-sm font-medium text-slate-500 mt-0.5">5 min away</span>
                   </div>
                   <div className="text-right">
                     <span className={`block font-black text-lg ${rideType === 'electric' ? 'text-slate-900' : 'text-slate-700'}`}>UGX 5,000</span>
                   </div>
                   {rideType === 'electric' && (
                     <div className="absolute -top-3 right-4 bg-green-500 text-white text-[10px] font-bold px-2 py-1 rounded-md tracking-wider shadow-sm uppercase">Eco-friendly</div>
                   )}
                </button>
              </div>

              <div className="pt-2 space-y-4">
                {/* Payment Method Selector */}
                <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-100 rounded-2xl active:bg-slate-100 transition-colors cursor-pointer">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-green-100 text-green-700 rounded-full flex items-center justify-center">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m-3-2.818l.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <p className="text-sm font-extrabold text-slate-900">Cash Payment</p>
                      <p className="text-xs font-medium text-slate-500">Pay rider directly</p>
                    </div>
                  </div>
                  <ChevronDown className="w-5 h-5 text-slate-400" />
                </div>

                <button 
                  onClick={placeOrder}
                  disabled={!destination || loading}
                  className="w-full py-4 bg-brand text-white rounded-2xl font-extrabold text-xl shadow-[0_8px_30px_rgb(218,165,32,0.3)] hover:bg-brand-dark active:scale-[0.98] transition-all disabled:opacity-50 disabled:bg-slate-300 disabled:shadow-none flex items-center justify-center gap-3 group border border-brand"
                >
                  {loading ? (
                    <Loader2 className="w-6 h-6 animate-spin" />
                  ) : null}
                  {loading ? 'Confirming...' : 'Confirm Order'}
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              className="w-full max-w-lg bg-white rounded-t-[32px] shadow-[0_-20px_60px_rgba(0,0,0,0.1)] p-6 pt-3 space-y-6"
            >
               <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto mb-4" />

               <div className="flex flex-col items-center text-center space-y-3">
                  <div className="relative">
                    <div className="w-20 h-20 bg-brand/10 rounded-full flex items-center justify-center relative z-10 border border-brand/20">
                       {activeRide.type === 'electric' ? <Zap className="w-8 h-8 text-brand" /> : <Bike className="w-8 h-8 text-brand" />}
                    </div>
                    {searching && (
                      <motion.div 
                         initial={{ scale: 1, opacity: 0.5 }}
                         animate={{ scale: 1.5, opacity: 0 }}
                         transition={{ repeat: Infinity, duration: 1.5 }}
                         className="absolute inset-0 bg-brand rounded-full -z-0"
                      />
                    )}
                  </div>
                  
                  <div className="space-y-1">
                    <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                       {activeRide.status === 'requested' ? 'Finding your Rider...' : activeRide.status === 'accepted' ? 'Boda is Arriving' : 'Ride in Progress'}
                    </h2>
                    <p className="text-slate-500 text-sm font-medium px-4">
                       {activeRide.status === 'requested' ? 'Connecting to verified riders nearby' : 'Your rider will be at the pickup point shortly'}
                    </p>
                  </div>
               </div>

               {/* Ride Status Progress Indicator */}
               <div className="w-full flex items-center justify-between relative px-6 py-2">
                 <div className="absolute left-8 right-8 top-5 h-1 bg-slate-100 -z-10 rounded-full" />
                 <div className="absolute left-8 top-5 h-1 bg-brand -z-10 rounded-full transition-all duration-500" style={{ width: activeRide.status === 'requested' ? '0%' : activeRide.status === 'accepted' ? '50%' : '100%' }} />
                 
                 <div className="flex flex-col items-center gap-1.5 z-10 bg-white">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ring-4 ring-white ${['requested', 'accepted', 'picked_up', 'completed'].includes(activeRide.status) ? 'bg-brand text-white shadow-sm shadow-brand/30' : 'bg-slate-200 text-slate-400'}`}>1</div>
                    <span className={`text-[10px] uppercase tracking-widest font-bold ${['requested', 'accepted', 'picked_up', 'completed'].includes(activeRide.status) ? 'text-slate-800' : 'text-slate-400'}`}>Search</span>
                 </div>

                 <div className="flex flex-col items-center gap-1.5 z-10 bg-white px-2">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ring-4 ring-white ${['accepted', 'picked_up', 'completed'].includes(activeRide.status) ? 'bg-brand text-white shadow-sm shadow-brand/30' : 'bg-slate-200 text-slate-400'}`}>2</div>
                    <span className={`text-[10px] uppercase tracking-widest font-bold ${['accepted', 'picked_up', 'completed'].includes(activeRide.status) ? 'text-slate-800' : 'text-slate-400'}`}>Accepted</span>
                 </div>

                 <div className="flex flex-col items-center gap-1.5 z-10 bg-white">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ring-4 ring-white ${['picked_up', 'completed'].includes(activeRide.status) ? 'bg-brand text-white shadow-sm shadow-brand/30' : 'bg-slate-200 text-slate-400'}`}>3</div>
                    <span className={`text-[10px] uppercase tracking-widest font-bold ${['picked_up', 'completed'].includes(activeRide.status) ? 'text-slate-800' : 'text-slate-400'}`}>En Route</span>
                 </div>
               </div>

               {activeRide.status !== 'requested' && (
                 <div className="space-y-3">
                   <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                      <div className="w-14 h-14 bg-white rounded-xl shadow-sm flex items-center justify-center">
                         <UserIcon className="w-6 h-6 text-slate-400" />
                      </div>
                      <div className="flex-1">
                         <div className="flex justify-between items-center">
                            <h4 className="font-bold text-slate-900 text-base">Mwesigwa K.</h4>
                            <div className="flex items-center gap-1 bg-white px-2 py-1 rounded-lg border border-slate-100 shadow-sm">
                               <Star className="w-3 h-3 fill-brand text-brand" />
                               <span className="font-bold text-xs text-slate-700">4.9</span>
                            </div>
                         </div>
                         <p className="text-slate-500 text-xs font-bold mt-1">Baja Boxer • UGX 340Z</p>
                      </div>
                   </div>

                   {riderLocation && (
                     <div className="flex items-center gap-3 bg-blue-50/50 border border-blue-100 p-4 rounded-2xl">
                       <MapPin className="w-5 h-5 text-blue-500 animate-bounce" />
                       <div className="flex-1">
                         <p className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">Live Location</p>
                         <p className="text-slate-700 text-xs font-mono">{riderLocation.lat.toFixed(5)}, {riderLocation.lng.toFixed(5)}</p>
                       </div>
                     </div>
                   )}
                 </div>
               )}

               <div className="bg-slate-50 p-4 rounded-2xl space-y-2 border border-slate-100">
                  <div className="flex justify-between items-center text-sm">
                     <span className="text-slate-400 font-bold">Estimated Fare</span>
                     <span className="text-slate-900 font-extrabold">{activeRide.price.toLocaleString()} UGX</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                     <span className="text-slate-400 font-bold">Destination</span>
                     <span className="text-slate-900 font-bold max-w-[200px] truncate text-right">{activeRide.destination.address}</span>
                  </div>
               </div>

               {activeRide.status === 'requested' && (
                 <button 
                  onClick={cancelRide}
                  className="w-full py-4 text-slate-500 font-bold hover:text-red-500 hover:bg-red-50 rounded-2xl transition-all"
                 >
                   Cancel Request
                 </button>
               )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

