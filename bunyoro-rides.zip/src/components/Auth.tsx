import React, { useEffect, useState } from 'react';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { signInAnonymously, onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { Bike, User as UserIcon, Smartphone, Loader2, Info, ChevronDown, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Role } from '../types';
import { Logo } from './Logo';

interface AuthProps {
  onAuthComplete: (user: User, role: Role) => void;
}

export const Auth: React.FC<AuthProps> = ({ onAuthComplete }) => {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const [needsRole, setNeedsRole] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    return onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        console.log("Firebase Auth State:", { u_uid: u.uid, current_user_uid: auth.currentUser?.uid });
        try {
          await u.getIdToken(true); // Force token refresh
          let userDoc;
          try {
            console.log("Executing getDoc on:", u.uid);
            userDoc = await getDoc(doc(db, 'users', u.uid));
            console.log("getDoc succeeded, exists:", userDoc.exists());
          } catch (err: any) {
             if (err?.code === 'permission-denied') {
               console.log("No profile found (permission denied). Assuming new user needs role selection.");
               setNeedsRole(true);
               setLoading(false);
               return; // Exit early safely
             } else {
               console.error("First getDoc failed:", err.code, err.message);
               throw err;
             }
          }
          if (userDoc && userDoc.exists()) {
            onAuthComplete(u, userDoc.data().role as Role);
          } else {
            setNeedsRole(true);
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${u.uid}`);
        }
      }
      setLoading(false);
    });
  }, [onAuthComplete]);

  const handleSignIn = async () => {
    if (isAuthenticating || !phoneNumber) return;
    setIsAuthenticating(true);
    setAuthError(null);
    
    // Ensure format +256...
    let formattedPhone = phoneNumber.trim().replace(/\s+/g, '');
    if (formattedPhone.startsWith('0')) {
      formattedPhone = '+256' + formattedPhone.substring(1);
    } else if (formattedPhone.startsWith('256')) {
      formattedPhone = '+' + formattedPhone;
    } else if (!formattedPhone.startsWith('+')) {
      formattedPhone = '+256' + formattedPhone;
    }

    try {
      await signInAnonymously(auth);
      // Wait for onAuthStateChanged to pick up the user, we keep it in loading state implicitly
    } catch (error: any) {
      console.error("Sign in failed", error);
      if (error.code === 'auth/admin-restricted-operation') {
         setAuthError("To test this mock flow without CAPTCHA, please enable 'Anonymous' in Firebase Console > Authentication > Sign-in method.");
      } else {
         setAuthError("Failed to sign in. Please try again.");
      }
      setIsAuthenticating(false);
    }
  };

  const selectRole = async (role: Role) => {
    let userPhone = user?.phoneNumber || phoneNumber;
    if (!userPhone && user?.providerData?.length) {
      userPhone = user.providerData.find(p => p.phoneNumber)?.phoneNumber || "unknown";
    }
    if (!userPhone) userPhone = "unknown";
    
    if (!user) {
      setAuthError("Session expired. Please sign in again.");
      return;
    }
    
    setIsAuthenticating(true);
    setAuthError(null);
    
    try {
      await setDoc(doc(db, 'users', user.uid), {
        phone: userPhone,
        role: role,
        updatedAt: serverTimestamp(),
      });
      
      console.log("Role selected:", role);
      onAuthComplete(user, role);
    } catch (error) {
      console.error("Role selection failed", error);
      setAuthError("Failed to save profile. Please try again.");
      // Don't throw here so we can show the error in UI
    } finally {
      setIsAuthenticating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-brand" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex flex-col h-screen bg-[#ec8408] shadow-inner">
        <div className="absolute inset-0 bg-pattern opacity-10 pointer-events-none" />
        
        {/* Splash Header */}
        <div className="flex-1 flex flex-col items-center justify-center p-8 space-y-6 relative z-10 bg-[#ec8408]">
           <motion.div
             initial={{ scale: 0.8, opacity: 0 }}
             animate={{ scale: 1, opacity: 1 }}
             transition={{ type: "spring", bounce: 0.5 }}
           >
             <Logo className="w-40 h-40 text-black drop-shadow-2xl" color="#000000" />
           </motion.div>
           <div className="w-full max-w-sm space-y-2">
             <h1 className="text-5xl font-bold font-sans text-black tracking-tighter uppercase">Bunyoro<span className="opacity-60">Rides</span></h1>
             <p className="font-serif italic text-left text-black/70 uppercase tracking-[0.2em] text-xs w-full">Premium Mobility</p>
           </div>
        </div>

        {/* Login Card */}
        <motion.div 
          initial={{ y: "100%" }}
          animate={{ y: 0 }}
          className="bg-white rounded-t-[32px] p-8 pb-12 space-y-8 shadow-[0_-20px_60px_rgba(0,0,0,0.1)] relative z-20"
        >
          <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto mb-2" />
          <div className="text-center space-y-1">
             <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Login</h2>
             <p className="text-slate-500 text-sm font-medium">Enter your number to start your journey</p>
          </div>

          <AnimatePresence mode="wait">
              <motion.div 
                key="phone"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-6 bg-slate-50 border border-slate-100 p-6 rounded-[24px] -mx-2 shadow-sm"
              >
                <div className="flex gap-3">
                   <div className="flex items-center gap-2 px-4 py-4 bg-white border border-slate-200 rounded-xl text-slate-900 font-extrabold shadow-sm">
                      <img src="https://flagcdn.com/w40/ug.png" alt="UG" className="w-6 h-4 rounded-sm object-cover" />
                      <span>+256</span>
                   </div>
                   <div className="flex-1 bg-white border border-slate-200 rounded-xl shadow-sm focus-within:ring-4 focus-within:ring-brand/20 focus-within:border-brand transition-all">
                      <input
                        type="tel"
                        placeholder="700 000 000"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        className="w-full h-full px-5 bg-transparent border-0 rounded-xl text-slate-900 font-extrabold text-lg placeholder:text-slate-400 focus:outline-none focus:ring-0 transition-all font-mono"
                      />
                   </div>
                </div>

                {authError && (
                  <div className="flex items-start gap-3 p-4 bg-red-50 rounded-xl border border-red-100">
                    <Info className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                    <p className="text-red-700 text-xs font-bold leading-relaxed">{authError}</p>
                  </div>
                )}

                <button
                  onClick={handleSignIn}
                  disabled={isAuthenticating || !phoneNumber}
                  className="w-full py-4 bg-brand text-white rounded-xl font-extrabold text-lg hover:bg-brand-dark transition-all disabled:opacity-50 disabled:bg-slate-300 shadow-[0_8px_30px_rgb(218,165,32,0.3)] active:scale-95 flex items-center justify-center gap-3"
                >
                  {isAuthenticating ? <Loader2 className="w-6 h-6 animate-spin" /> : 'Continue'}
                </button>

                <div className="flex flex-col items-center gap-1.5 pt-2">
                  <div className="flex items-center gap-1.5 text-slate-500 text-[11px] font-bold uppercase tracking-widest">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Secure Verification</span>
                  </div>
                </div>
              </motion.div>
          </AnimatePresence>
        </motion.div>
      </div>
    );
  }

  if (needsRole) {
    return (
      <div className="flex flex-col h-screen min-h-[600px] bg-[#f8f9fa] font-sans overflow-y-auto">
        {/* Subtle background art */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand/5 rounded-full blur-[100px] translate-x-1/3 -translate-y-1/3" />
          <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-slate-300/20 rounded-full blur-[80px] -translate-x-1/3 translate-y-1/3" />
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="px-8 pt-16 pb-8 space-y-8 relative z-10 w-full max-w-md mx-auto flex-none"
        >
           <div className="w-16 h-16 bg-brand rounded-3xl flex items-center justify-center shadow-[0_8px_30px_rgb(236,132,8,0.4)] rotate-3">
             <Logo className="w-10 h-10 text-black -rotate-3" color="#000000" />
           </div>
           
           <div className="space-y-2">
             <h1 className="text-5xl font-black text-slate-900 tracking-tighter leading-[0.9]">
               CHOOSE<br />
               YOUR<br />
               <span className="text-brand">JOURNEY</span>
             </h1>
             <p className="font-serif italic text-slate-500 pt-2 text-sm">How would you like to use Bunyoro Rides?</p>
           </div>
        </motion.div>
        
        <div className="flex-1 flex flex-col justify-start px-8 pb-12 gap-5 relative z-10 w-full max-w-md mx-auto">
          <motion.button
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1, ease: "easeOut" }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => selectRole('client')}
            disabled={isAuthenticating}
            className="group relative flex-none h-[200px] p-8 bg-white border-2 border-slate-100/50 rounded-[40px] hover:border-brand hover:shadow-2xl hover:shadow-brand/20 transition-all text-left overflow-hidden disabled:opacity-50"
          >
            {/* Background Art */}
            <div className="absolute top-0 right-0 w-full h-full opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none">
              <svg className="absolute top-0 right-0 w-64 h-64 text-brand/10 -translate-y-8 translate-x-8" viewBox="0 0 100 100" fill="currentColor">
                <circle cx="50" cy="50" r="40" stroke="currentColor" strokeWidth="2" fill="none" strokeDasharray="4 4" />
                <circle cx="50" cy="50" r="28" stroke="currentColor" strokeWidth="1" fill="none" />
                <circle cx="50" cy="50" r="15" fill="currentColor" className="opacity-20" />
              </svg>
            </div>
            
            <div className="absolute -bottom-8 -right-8 w-48 h-48 bg-brand/10 rounded-full blur-3xl group-hover:bg-brand/20 transition-colors duration-500" />
            
            <div className="absolute right-6 bottom-6 opacity-[0.03] group-hover:opacity-10 transition-all duration-500 group-hover:scale-110 group-hover:-rotate-12 group-hover:translate-x-2">
                <UserIcon size={140} />
            </div>

            <div className="relative z-10 flex flex-col h-full justify-between pointer-events-none">
              <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center shadow-sm group-hover:bg-brand group-hover:shadow-brand/40 transition-all duration-500">
                {isAuthenticating ? (
                  <Loader2 className="w-6 h-6 text-brand animate-spin" />
                ) : (
                  <UserIcon className="w-6 h-6 text-slate-400 group-hover:text-black transition-colors duration-300" />
                )}
              </div>
              <div>
                <span className="block font-black text-3xl text-slate-900 uppercase tracking-tight">Client</span>
                <div className="flex items-center gap-2 mt-2">
                  <span className="w-2 h-2 rounded-full bg-brand group-hover:animate-pulse" />
                  <p className="text-slate-500 font-bold text-xs uppercase tracking-widest leading-none">Premium Rides</p>
                </div>
              </div>
            </div>
          </motion.button>

          <motion.button
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2, ease: "easeOut" }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => selectRole('rider')}
            disabled={isAuthenticating}
            className="group relative flex-none h-[200px] p-8 bg-slate-900 rounded-[40px] shadow-xl hover:shadow-brand/30 transition-all text-left overflow-hidden disabled:opacity-50"
          >
            {/* Background Art */}
            <div className="absolute inset-0 opacity-20 group-hover:opacity-40 transition-opacity duration-700 pointer-events-none">
              <div className="absolute right-0 top-0 w-32 h-[200%] bg-gradient-to-l from-brand/40 to-transparent skew-x-[-25deg] translate-x-12 -translate-y-1/4 group-hover:translate-x-4 transition-transform duration-700" />
              <div className="absolute right-16 top-0 w-8 h-[200%] bg-gradient-to-l from-brand/50 to-transparent skew-x-[-25deg] translate-x-12 -translate-y-1/4 group-hover:-translate-x-2 transition-transform duration-500" />
            </div>

            <div className="absolute -bottom-8 -right-8 w-48 h-48 bg-brand/20 rounded-full blur-3xl group-hover:bg-brand/40 transition-colors duration-500" />
            
            <div className="absolute -right-2 -bottom-2 opacity-[0.05] group-hover:opacity-20 transition-all duration-500 group-hover:scale-110 group-hover:rotate-12 group-hover:-translate-y-2">
                <Bike size={160} className="text-white" />
            </div>

            <div className="relative z-10 flex flex-col h-full justify-between pointer-events-none">
              <div className="w-14 h-14 bg-white/10 backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-lg group-hover:bg-brand transition-all duration-500">
                {isAuthenticating ? (
                  <Loader2 className="w-6 h-6 text-brand animate-spin" />
                ) : (
                  <Bike className="w-6 h-6 text-white group-hover:text-black transition-colors duration-300" />
                )}
              </div>
              <div>
                <span className="block font-black text-3xl text-white uppercase tracking-tight">Rider</span>
                <div className="flex items-center gap-2 mt-2">
                  <span className="w-2 h-2 rounded-full bg-[#ec8408]" />
                  <p className="text-[#ec8408] font-bold text-xs uppercase tracking-widest leading-none">Join the Fleet</p>
                </div>
              </div>
            </div>
          </motion.button>
        </div>

        {authError && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="px-8 pb-10 max-w-md mx-auto w-full"
          >
             <div className="flex items-center gap-3 p-4 bg-red-50 rounded-2xl border border-red-100">
               <Info className="w-4 h-4 text-red-500 shrink-0" />
               <p className="text-red-700 text-xs font-bold leading-relaxed">{authError}</p>
             </div>
          </motion.div>
        )}
      </div>
    );
  }

  return null;
};
