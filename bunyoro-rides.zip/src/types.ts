export type Role = 'client' | 'rider';
export type RideStatus = 'requested' | 'accepted' | 'picked_up' | 'completed' | 'cancelled';
export type RideType = 'usual' | 'electric';

export interface Location {
  lat: number;
  lng: number;
  address?: string;
  timestamp?: number;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL: string;
  role: Role;
  location?: Location;
  isOnline?: boolean;
  updatedAt: any; // ServerTimestamp
}

export interface Ride {
  id: string;
  clientId: string;
  riderId?: string;
  pickup: Location;
  destination: Location;
  type: RideType;
  status: RideStatus;
  price: number;
  createdAt: any;
  updatedAt: any;
}
