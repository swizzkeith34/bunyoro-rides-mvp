/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { User } from 'firebase/auth';
import { Auth } from './components/Auth';
import { ClientDashboard } from './components/ClientDashboard';
import { RiderDashboard } from './components/RiderDashboard';
import { Role } from './types';
import { LogOut, Bike, MapPin } from 'lucide-react';
import { auth } from './lib/firebase';

export default function App() {
  const [session, setSession] = useState<{ user: User; role: Role } | null>(null);

  const handleLogout = () => {
    auth.signOut();
    setSession(null);
  };

  if (!session) {
    return <Auth onAuthComplete={(user, role) => setSession({ user, role })} />;
  }

  return (
    <div className="min-h-screen bg-black font-sans text-white selection:bg-brand selection:text-black">
      {/* Global Navigation */}
      <nav className="sticky top-0 z-50 bg-black/80 backdrop-blur-md border-b border-white/5 px-6 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-brand rounded-xl flex items-center justify-center shadow-lg shadow-brand/20">
            <Bike className="text-black w-6 h-6" />
          </div>
          <h1 className="font-bold text-lg tracking-tight text-white italic">Bunyoro<span className="text-brand">Rides</span></h1>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="hidden sm:block text-right">
             <p className="text-[10px] font-bold text-brand uppercase tracking-widest">{session.role}</p>
             <p className="text-sm font-bold text-slate-300">{session.user.phoneNumber}</p>
          </div>
          <button 
            onClick={handleLogout}
            className="w-10 h-10 flex items-center justify-center bg-white/5 hover:bg-red-500/10 rounded-xl transition-all text-slate-500 hover:text-red-500 border border-white/5"
            title="Logout"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </nav>

      <main className="mx-auto max-w-7xl pb-24 sm:pb-8">
        {session.role === 'client' ? (
          <ClientDashboard userId={session.user.uid} />
        ) : (
          <RiderDashboard userId={session.user.uid} />
        )}
      </main>

      {/* Modern Tab Bar for Mobile */}
      <div className="fixed bottom-0 left-0 right-0 p-6 sm:hidden pointer-events-none">
          <div className="bg-black/60 backdrop-blur-2xl border border-white/10 mx-auto rounded-[32px] flex items-center justify-around p-4 shadow-2xl pointer-events-auto max-w-sm">
              <button className="flex flex-col items-center gap-1 text-brand">
                 <MapPin className="w-6 h-6" />
                 <span className="text-[8px] font-extrabold uppercase tracking-widest">Explore</span>
              </button>
              <button className="flex flex-col items-center gap-1 text-slate-600">
                 <Bike className="w-6 h-6" />
                 <span className="text-[8px] font-extrabold uppercase tracking-widest">Rides</span>
              </button>
              <button className="flex flex-col items-center gap-1 text-slate-600">
                  <div className="w-12 h-5 rounded-full overflow-hidden border border-slate-700 flex items-center justify-center bg-slate-800">
                     <span className="text-[6px] text-slate-500 font-mono italic">ID:{session.user.uid.slice(0,4)}</span>
                  </div>
                 <span className="text-[8px] font-extrabold uppercase tracking-widest">Account</span>
              </button>
          </div>
      </div>
    </div>
  );
}
